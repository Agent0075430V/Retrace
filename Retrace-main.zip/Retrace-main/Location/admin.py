from django.contrib import admin
from .models import Location  # Replace 'YourModel' with your actual model name

# Register your models here.
admin.site.register(Location)
